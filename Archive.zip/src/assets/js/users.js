document.addEventListener('DOMContentLoaded', async () => {
    // Check auth via script.js checkAuth method
    checkAuth();

    // Pastikan hanya K3 admin yang bisa akses
    if (!hasRole('k3')) {
        window.location.href = 'index.html';
        return;
    }

    // Load users from localStorage
    loadUsers();

    // Fetch users from Supabase
    await fetchUsersFromSupabase();

    renderUsers();

    // Inisialisasi TomSelect untuk Role
    if (typeof TomSelect !== 'undefined') {
        new TomSelect('#userRole', {
            create: false,
            sortField: {
                field: "text",
                direction: "asc"
            }
        });
    }
});

// Load users from localStorage sync with script.js USERS
function loadUsers() {
    try {
        const savedUsers = localStorage.getItem('assessment5r_users');
        if (savedUsers) {
            USERS = JSON.parse(savedUsers);
        }
    } catch(e) {
        console.error('Error loading users:', e);
    }
}

// Fetch users from Supabase
async function fetchUsersFromSupabase() {
    try {
        const users = await SupabaseAPI.get('users');
        if (users && users.length > 0) {
            USERS = users;
            localStorage.setItem('assessment5r_users', JSON.stringify(USERS));
        }
    } catch(e) {
        console.error('Error fetching users from Supabase:', e);
        // Fallback to localStorage if API fails
        loadUsers();
    }
}

function renderUsers() {
    const tableBody = document.getElementById('usersTable');
    const emptyState = document.getElementById('emptyUsers');

    if (USERS.length === 0) {
        tableBody.innerHTML = '';
        emptyState.style.display = 'block';
        return;
    }

    emptyState.style.display = 'none';

    tableBody.innerHTML = USERS.map(u => `
        <tr>
            <td><strong>${escapeHtml(u.name)}</strong></td>
            <td>${escapeHtml(u.username)}</td>
            <td>
                <span style="padding:4px 10px; border-radius:12px; font-size:0.75rem; font-weight:600;
                      background:${u.role === 'k3' ? '#fee2e2' : '#e0e7ff'};
                      color:${u.role === 'k3' ? '#dc2626' : '#4f46e5'}">
                    ${escapeHtml(u.role).toUpperCase()}
                </span>
            </td>
            <td>
                <div style="display:flex; gap:0.5rem;">
                    <button class="btn btn-sm btn-secondary" onclick="editUser('${u.id}')" title="Edit">
                        Edit
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteUser('${u.id}')" title="Hapus" ${['u1','u2'].includes(u.id) ? 'disabled style="opacity:0.5;cursor:not-allowed;"' : ''}>
                        Hapus
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

function openUserModal() {
    document.getElementById('userId').value = '';
    document.getElementById('userName').value = '';
    document.getElementById('userUsername').value = '';
    document.getElementById('userPassword').value = '';
    document.getElementById('userPassword').required = true;
    document.getElementById('passwordHint').style.display = 'none';

    const roleSelect = document.getElementById('userRole');
    if (roleSelect.tomselect) {
        roleSelect.tomselect.setValue('user');
    } else {
        roleSelect.value = 'user';
    }

    document.getElementById('modalTitle').textContent = 'Tambah User Baru';
    document.getElementById('userModal').classList.add('active');
}

function closeUserModal() {
    document.getElementById('userModal').classList.remove('active');
}

function editUser(id) {
    const user = USERS.find(u => u.id === id);
    if (!user) return;

    document.getElementById('userId').value = user.id;
    document.getElementById('userName').value = user.name;
    document.getElementById('userUsername').value = user.username;

    document.getElementById('userPassword').value = '';
    document.getElementById('userPassword').required = false;
    document.getElementById('passwordHint').style.display = 'inline';

    const roleSelect = document.getElementById('userRole');
    if (roleSelect.tomselect) {
        roleSelect.tomselect.setValue(user.role);
    } else {
        roleSelect.value = user.role;
    }

    document.getElementById('modalTitle').textContent = 'Edit User';
    document.getElementById('userModal').classList.add('active');
}

async function deleteUser(id) {
    if (id === 'u1' || id === 'u2') {
        showToast('User bawaan sistem tidak dapat dihapus!');
        return;
    }

    if (confirm('Yakin ingin menghapus user ini?')) {
        try {
            // Delete from Supabase
            await SupabaseAPI.delete('users', { 'id': `eq.${id}` });

            // Update local
            USERS = USERS.filter(u => u.id !== id);
            localStorage.setItem('assessment5r_users', JSON.stringify(USERS));

            renderUsers();
            showToast('User berhasil dihapus!');
        } catch(e) {
            console.error('Error deleting user:', e);
            alert('Gagal menghapus user: ' + e.message);
        }
    }
}

async function handleUserSubmit(e) {
    e.preventDefault();

    const id = document.getElementById('userId').value;
    const name = document.getElementById('userName').value;
    const username = document.getElementById('userUsername').value;
    const password = document.getElementById('userPassword').value;
    const role = document.getElementById('userRole').value;

    try {
        if (id) {
            // Edit - Update user in Supabase
            const userIndex = USERS.findIndex(u => u.id === id);
            if (userIndex !== -1) {
                // Check username duplicate for others
                if (USERS.some(u => u.username === username && u.id !== id)) {
                    alert('Username sudah digunakan user lain!');
                    return;
                }

                const updateData = { name, username, role };
                if (password) {
                    updateData.password = password;
                }

                await SupabaseAPI.patch('users', updateData, { 'id': `eq.${id}` });

                // Update local
                USERS[userIndex] = { ...USERS[userIndex], ...updateData };
                localStorage.setItem('assessment5r_users', JSON.stringify(USERS));

                showToast('Data user berhasil diperbarui!');
            }
        } else {
            // Create - Add new user to Supabase
            // Check if username exists
            if (USERS.some(u => u.username === username)) {
                alert('Username sudah terdaftar!');
                return;
            }

            const newUser = {
                name,
                username,
                password,
                role
            };

            const result = await SupabaseAPI.post('users', newUser);

            // Update local with returned data (including any server-generated fields)
            if (result && result.length > 0) {
                USERS.push(result[0]);
            } else {
                USERS.push(newUser);
            }

            localStorage.setItem('assessment5r_users', JSON.stringify(USERS));
            showToast('User baru berhasil ditambahkan!');
        }

        renderUsers();
        closeUserModal();
    } catch(e) {
        console.error('Error saving user:', e);
        alert('Gagal menyimpan user: ' + e.message);
    }
}
