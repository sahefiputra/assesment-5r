// =====================
// Auth System
// =====================
let USERS = [];
try {
    const savedUsers = localStorage.getItem('assessment5r_users');
    if (savedUsers) {
        USERS = JSON.parse(savedUsers);
    } else {
        USERS = [
            { id: 'u1', username: 'user', password: 'user123', role: 'user', name: 'User Demo' },
            { id: 'u2', username: 'k3', password: 'k3admin', role: 'k3', name: 'Tim K3' }
        ];
        localStorage.setItem('assessment5r_users', JSON.stringify(USERS));
    }
} catch(e) {
    console.error(e);
}

const SESSION_KEY = 'assessment5r_session';
const STORAGE_KEY = 'assessment5r_data';

function checkAuth() {
    // Login page tidak perlu cek auth
    if (window.location.pathname.includes('login.html')) {
        return;
    }

    const session = localStorage.getItem(SESSION_KEY);
    if (!session) {
        window.location.href = 'login.html';
        return;
    }
}

async function handleLogin(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        // Cek ke Supabase dulu
        const result = await SupabaseAPI.get('users', {
            'username': `eq.${username}`,
            'password': `eq.${password}`
        });

        if (result && result.length > 0) {
            const user = result[0];
            const session = {
                username: user.username,
                role: user.role,
                name: user.name,
                loginTime: new Date().toISOString()
            };
            localStorage.setItem(SESSION_KEY, JSON.stringify(session));
            window.location.href = 'index.html';
            return;
        }

        // Fallback ke local USERS (untuk default users)
        const user = USERS.find(u => u.username === username && u.password === password);

        if (user) {
            const session = {
                username: user.username,
                role: user.role,
                name: user.name,
                loginTime: new Date().toISOString()
            };
            localStorage.setItem(SESSION_KEY, JSON.stringify(session));
            window.location.href = 'index.html';
        } else {
            const errorEl = document.getElementById('loginError');
            errorEl.style.display = 'block';
            setTimeout(() => {
                errorEl.style.display = 'none';
            }, 3000);
        }
    } catch (e) {
        console.error('Login error:', e);
        // Jika API error, coba cek local USERS
        const user = USERS.find(u => u.username === username && u.password === password);
        if (user) {
            const session = {
                username: user.username,
                role: user.role,
                name: user.name,
                loginTime: new Date().toISOString()
            };
            localStorage.setItem(SESSION_KEY, JSON.stringify(session));
            window.location.href = 'index.html';
        } else {
            alert('Gagal login: ' + e.message);
        }
    }
}

function handleLogout() {
    localStorage.removeItem(SESSION_KEY);
    window.location.href = 'login.html';
}

function getCurrentUser() {
    const session = localStorage.getItem(SESSION_KEY);
    return session ? JSON.parse(session) : null;
}

function hasRole(role) {
    const user = getCurrentUser();
    return user && user.role === role;
}

// =====================
// Storage Management
// =====================
function getAssessments() {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
}

function saveAssessments(assessments) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(assessments));
}

// =====================
// Scoring System
// =====================
function calculateScores(data) {
    // R1: 5 questions
    const r1 = calculateAspectScore(data, ['q1_1', 'q1_2', 'q1_3', 'q1_4', 'q1_5']);
    // R2: 5 questions
    const r2 = calculateAspectScore(data, ['q2_1', 'q2_2', 'q2_3', 'q2_4', 'q2_5']);
    // R3: 5 questions
    const r3 = calculateAspectScore(data, ['q3_1', 'q3_2', 'q3_3', 'q3_4', 'q3_5']);
    // R4: 2 questions
    const r4 = calculateAspectScore(data, ['q4_1', 'q4_2']);
    // R5: 5 questions
    const r5 = calculateAspectScore(data, ['q5_1', 'q5_2', 'q5_3', 'q5_4', 'q5_5']);

    const total = (r1 + r2 + r3 + r4 + r5) / 5;

    return { r1, r2, r3, r4, r5, total };
}

function calculateAspectScore(data, questions) {
    let points = 0;
    questions.forEach(q => {
        if (data[q] === 'Ya') points++;
    });
    return (points / questions.length) * 100;
}

// =====================
// Dashboard Functions
// =====================
function updateStats() {
    const user = getCurrentUser();
    let assessments = getAssessments();

    // User hanya lihat assessment sendiri
    if (user.role === 'user') {
        assessments = assessments.filter(a => a.createdBy === user.username);
    }

    document.getElementById('statTotal').textContent = assessments.length;

    const uniqueDivisi = [...new Set(assessments.map(a => a.divisi))];
    document.getElementById('statDivisi').textContent = uniqueDivisi.length;

    // Untuk K3, tambahkan stats nilai
    if (user.role === 'k3' && assessments.length > 0) {
        const avgScores = calculateAverageScores(assessments);
        document.getElementById('statAvgR1').textContent = avgScores.r1.toFixed(1);
        document.getElementById('statAvgR2').textContent = avgScores.r2.toFixed(1);
        document.getElementById('statAvgR3').textContent = avgScores.r3.toFixed(1);
        document.getElementById('statAvgR4').textContent = avgScores.r4.toFixed(1);
        document.getElementById('statAvgR5').textContent = avgScores.r5.toFixed(1);
        document.getElementById('statAvgTotal').textContent = avgScores.total.toFixed(1);
    }
}

function calculateAverageScores(assessments) {
    let r1 = 0, r2 = 0, r3 = 0, r4 = 0, r5 = 0, total = 0;

    assessments.forEach(a => {
        if (a.scores) {
            r1 += a.scores.r1;
            r2 += a.scores.r2;
            r3 += a.scores.r3;
            r4 += a.scores.r4;
            r5 += a.scores.r5;
            total += a.scores.total;
        }
    });

    const count = assessments.length;
    return {
        r1: r1 / count,
        r2: r2 / count,
        r3: r3 / count,
        r4: r4 / count,
        r5: r5 / count,
        total: total / count
    };
}

function renderAssessments() {
    const user = getCurrentUser();
    let assessments = getAssessments();

    // User hanya lihat assessment sendiri
    if (user.role === 'user') {
        assessments = assessments.filter(a => a.createdBy === user.username);
    }

    const tableBody = document.getElementById('assessmentTable');
    const emptyState = document.getElementById('emptyState');
    const searchInput = document.getElementById('searchInput');
    const filterDivisi = document.getElementById('filterDivisi');

    const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
    const divisiFilter = filterDivisi ? filterDivisi.value : 'all';

    let filtered = assessments.filter(a => {
        const matchesSearch = a.nama.toLowerCase().includes(searchTerm) ||
                             a.divisi.toLowerCase().includes(searchTerm) ||
                             a.jabatan.toLowerCase().includes(searchTerm);
        const matchesDivisi = divisiFilter === 'all' || a.divisi === divisiFilter;
        return matchesSearch && matchesDivisi;
    });

    // Sort by total score (K3 only)
    if (user.role === 'k3') {
        const sortValue = document.getElementById('sortValue')?.value || 'desc';
        filtered.sort((a, b) => {
            const scoreA = a.scores?.total || 0;
            const scoreB = b.scores?.total || 0;
            return sortValue === 'desc' ? scoreB - scoreA : scoreA - scoreB;
        });
    }

    if (filtered.length === 0) {
        tableBody.innerHTML = '';
        emptyState.style.display = 'flex';
        return;
    }

    emptyState.style.display = 'none';

    if (user.role === 'k3') {
        // K3 view - dengan nilai
        tableBody.innerHTML = filtered.map(a => `
            <tr>
                <td><strong>${escapeHtml(a.nama)}</strong></td>
                <td>${escapeHtml(a.divisi)}</td>
                <td>${escapeHtml(a.jabatan)}</td>
                <td>${escapeHtml(a.periode)}</td>
                <td>${formatDate(a.createdAt)}</td>
                <td class="score-cell">${a.scores?.r1.toFixed(0) || '-'}</td>
                <td class="score-cell">${a.scores?.r2.toFixed(0) || '-'}</td>
                <td class="score-cell">${a.scores?.r3.toFixed(0) || '-'}</td>
                <td class="score-cell">${a.scores?.r4.toFixed(0) || '-'}</td>
                <td class="score-cell">${a.scores?.r5.toFixed(0) || '-'}</td>
                <td class="score-cell score-total"><strong>${a.scores?.total.toFixed(1) || '-'}</strong></td>
                <td>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn btn-sm btn-outline" onclick="viewAssessment('${a.id}')" title="Lihat">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                            </svg>
                        </button>
                        ${user.role === 'user' ? `
                        <button class="btn btn-sm btn-secondary" onclick="editAssessment('${a.id}')" title="Edit">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
                                <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
                            </svg>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteAssessment('${a.id}')" title="Hapus">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                            </svg>
                        </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `).join('');
    } else {
        // User view - tanpa nilai
        tableBody.innerHTML = filtered.map(a => `
            <tr>
                <td><strong>${escapeHtml(a.nama)}</strong></td>
                <td>${escapeHtml(a.divisi)}</td>
                <td>${escapeHtml(a.jabatan)}</td>
                <td>${escapeHtml(a.periode)}</td>
                <td>${formatDate(a.createdAt)}</td>
                <td>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn btn-sm btn-outline" onclick="viewAssessment('${a.id}')" title="Lihat">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                            </svg>
                        </button>
                        <button class="btn btn-sm btn-secondary" onclick="editAssessment('${a.id}')" title="Edit">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
                                <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
                            </svg>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteAssessment('${a.id}')" title="Hapus">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                            </svg>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }
}

function renderCharts() {
    const assessments = getAssessments();

    if (assessments.length === 0) {
        document.getElementById('chartsSection').style.display = 'none';
        return;
    }

    // Calculate averages
    const avgScores = calculateAverageScores(assessments);

    // Bar Chart - Average per aspect
    renderBarChart(avgScores);

    // Line Chart - Trend by periode
    renderLineChart(assessments);

    // Pie Chart - Distribution by divisi
    renderPieChart(assessments);
}

function renderBarChart(avgScores) {
    const ctx = document.getElementById('barChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Ringkas (R1)', 'Rapi (R2)', 'Resik (R3)', 'Rawat (R4)', 'Rajin (R5)'],
            datasets: [{
                label: 'Rata-rata Nilai',
                data: [avgScores.r1, avgScores.r2, avgScores.r3, avgScores.r4, avgScores.r5],
                backgroundColor: [
                    'rgba(99, 102, 241, 0.8)',
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(6, 182, 212, 0.8)',
                    'rgba(245, 158, 11, 0.8)',
                    'rgba(139, 92, 246, 0.8)'
                ],
                borderColor: [
                    'rgb(99, 102, 241)',
                    'rgb(16, 185, 129)',
                    'rgb(6, 182, 212)',
                    'rgb(245, 158, 11)',
                    'rgb(139, 92, 246)'
                ],
                borderWidth: 2,
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { callback: value => value + '%' }
                }
            }
        }
    });
}

function renderLineChart(assessments) {
    // Group by periode
    const periodeData = {};
    assessments.forEach(a => {
        if (!periodeData[a.periode]) {
            periodeData[a.periode] = { total: 0, count: 0 };
        }
        if (a.scores) {
            periodeData[a.periode].total += a.scores.total;
            periodeData[a.periode].count++;
        }
    });

    const labels = Object.keys(periodeData).sort();
    const data = labels.map(p => (periodeData[p].total / periodeData[p].count).toFixed(1));

    const ctx = document.getElementById('lineChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Rata-rata Total Nilai',
                data: data,
                borderColor: 'rgb(99, 102, 241)',
                backgroundColor: 'rgba(99, 102, 241, 0.1)',
                fill: true,
                tension: 0.4,
                pointRadius: 6,
                pointHoverRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { callback: value => value + '%' }
                }
            }
        }
    });
}

function renderPieChart(assessments) {
    const divisiData = {};
    assessments.forEach(a => {
        divisiData[a.divisi] = (divisiData[a.divisi] || 0) + 1;
    });

    const ctx = document.getElementById('pieChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(divisiData),
            datasets: [{
                data: Object.values(divisiData),
                backgroundColor: [
                    'rgba(99, 102, 241, 0.8)',
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(6, 182, 212, 0.8)',
                    'rgba(245, 158, 11, 0.8)',
                    'rgba(139, 92, 246, 0.8)',
                    'rgba(239, 68, 68, 0.8)',
                    'rgba(236, 72, 153, 0.8)',
                    'rgba(20, 184, 166, 0.8)',
                    'rgba(132, 204, 22, 0.8)',
                    'rgba(249, 115, 22, 0.8)',
                    'rgba(99, 102, 241, 0.6)',
                    'rgba(16, 185, 129, 0.6)'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: { boxWidth: 12, padding: 15 }
                }
            }
        }
    });
}

function viewAssessment(id) {
    const assessments = getAssessments();
    const assessment = assessments.find(a => a.id === id);

    if (!assessment) return;

    const modalBody = document.getElementById('modalBody');

    let scoresHtml = '';
    if (assessment.scores) {
        scoresHtml = `
            <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 0.5rem; margin-bottom: 1rem;">
                <div style="text-align: center; padding: 0.75rem; background: #f3f4f6; border-radius: 8px;">
                    <div style="font-size: 0.75rem; color: #6b7280;">R1</div>
                    <div style="font-weight: 700; color: #6366f1;">${assessment.scores.r1.toFixed(0)}</div>
                </div>
                <div style="text-align: center; padding: 0.75rem; background: #f3f4f6; border-radius: 8px;">
                    <div style="font-size: 0.75rem; color: #6b7280;">R2</div>
                    <div style="font-weight: 700; color: #10b981;">${assessment.scores.r2.toFixed(0)}</div>
                </div>
                <div style="text-align: center; padding: 0.75rem; background: #f3f4f6; border-radius: 8px;">
                    <div style="font-size: 0.75rem; color: #6b7280;">R3</div>
                    <div style="font-weight: 700; color: #06b6d4;">${assessment.scores.r3.toFixed(0)}</div>
                </div>
                <div style="text-align: center; padding: 0.75rem; background: #f3f4f6; border-radius: 8px;">
                    <div style="font-size: 0.75rem; color: #6b7280;">R4</div>
                    <div style="font-weight: 700; color: #f59e0b;">${assessment.scores.r4.toFixed(0)}</div>
                </div>
                <div style="text-align: center; padding: 0.75rem; background: #f3f4f6; border-radius: 8px;">
                    <div style="font-size: 0.75rem; color: #6b7280;">R5</div>
                    <div style="font-weight: 700; color: #8b5cf6;">${assessment.scores.r5.toFixed(0)}</div>
                </div>
            </div>
            <div style="text-align: center; padding: 1rem; background: #eff6ff; border-radius: 8px; margin-bottom: 2rem;">
                <span style="color: #6b7280;">Total Nilai:</span>
                <span style="font-size: 1.5rem; font-weight: 700; color: #6366f1; margin-left: 0.5rem;">${assessment.scores.total.toFixed(1)}</span>
            </div>
        `;
    }

    modalBody.innerHTML = `
        <div style="margin-bottom: 2rem;">
            <h4 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 1rem; color: #1f2937;">Informasi Umum</h4>
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
                <div><strong>Nama:</strong> ${escapeHtml(assessment.nama)}</div>
                <div><strong>Divisi:</strong> ${escapeHtml(assessment.divisi)}</div>
                <div><strong>Jabatan:</strong> ${escapeHtml(assessment.jabatan)}</div>
                <div><strong>Periode:</strong> ${escapeHtml(assessment.periode)}</div>
                <div><strong>Tanggal:</strong> ${formatDate(assessment.createdAt)}</div>
            </div>
        </div>
        ${scoresHtml}
        <div style="margin-bottom: 2rem;">
            <h4 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 1rem; color: #6366f1;">Aspek Ringkas (R1)</h4>
            <div style="background: #f9fafb; border-radius: 0.75rem; padding: 1rem;">
                <p><strong>Area/Meja Kerja:</strong> ${assessment.q1_1 || '-'}</p>
                <p><strong>Dokumen di Rak/Lemari:</strong> ${assessment.q1_2 || '-'}</p>
                <p><strong>Peralatan Kerja:</strong> ${assessment.q1_3 || '-'}</p>
                <p><strong>Pemahaman Tata Cara Membuang Barang:</strong> ${assessment.q1_4 || '-'}</p>
                ${assessment.penjelasan1_4 ? `<p style="margin-top: 0.5rem; color: #6b7280;"><em>${escapeHtml(assessment.penjelasan1_4)}</em></p>` : ''}
                <p><strong>Penyimpanan Barang & Inventaris:</strong> ${assessment.q1_5 || '-'}</p>
            </div>
        </div>

        <div style="margin-bottom: 2rem;">
            <h4 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 1rem; color: #10b981;">Aspek Rapi (R2)</h4>
            <div style="background: #f9fafb; border-radius: 0.75rem; padding: 1rem;">
                <p><strong>Pelabelan:</strong> ${assessment.q2_1 || '-'}</p>
                <p><strong>Penataan Barang/Arsip/Inventaris:</strong> ${assessment.q2_2 || '-'}</p>
                <p><strong>Tempat Penyimpanan:</strong> ${assessment.q2_3 || '-'}</p>
                <p><strong>Penataan Area/Meja Kerja:</strong> ${assessment.q2_4 || '-'}</p>
                <p><strong>Layout Zonasi Ruang:</strong> ${assessment.q2_5 || '-'}</p>
            </div>
        </div>

        <div style="margin-bottom: 2rem;">
            <h4 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 1rem; color: #06b6d4;">Aspek Resik (R3)</h4>
            <div style="background: #f9fafb; border-radius: 0.75rem; padding: 1rem;">
                <p><strong>Lantai, Dinding, Langit-langit, Area Kerja:</strong> ${assessment.q3_1 || '-'}</p>
                <p><strong>Kebersihan Peralatan Kerja:</strong> ${assessment.q3_2 || '-'}</p>
                <p><strong>Kebersihan Alat Makan & Tempat Sampah:</strong> ${assessment.q3_3 || '-'}</p>
                <p><strong>Kebiasaan Resik Karyawan:</strong> ${assessment.q3_4 || '-'}</p>
                <p><strong>Sistem Kebersihan:</strong> ${assessment.q3_5 || '-'}</p>
            </div>
        </div>

        <div style="margin-bottom: 2rem;">
            <h4 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 1rem; color: #f59e0b;">Aspek Rawat (R4)</h4>
            <div style="background: #f9fafb; border-radius: 0.75rem; padding: 1rem;">
                <p><strong>Mekanisme Kendali Visual:</strong> ${assessment.q4_1 || '-'}</p>
                <p><strong>Peralatan, Fasilitas, Area Kerja:</strong> ${assessment.q4_2 || '-'}</p>
            </div>
        </div>

        <div style="margin-bottom: 2rem;">
            <h4 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 1rem; color: #8b5cf6;">Aspek Rajin (R5)</h4>
            <div style="background: #f9fafb; border-radius: 0.75rem; padding: 1rem;">
                <p><strong>Kesadaran Penerapan 4R:</strong> ${assessment.q5_1 || '-'}</p>
                ${assessment.penjelasan5_1 ? `<p style="margin-top: 0.5rem; color: #6b7280;"><em>${escapeHtml(assessment.penjelasan5_1)}</em></p>` : ''}
                <p style="margin-top: 1rem;"><strong>Sikap Kerja Personel:</strong> ${assessment.q5_2 || '-'}</p>
                ${assessment.penjelasan5_2 ? `<p style="margin-top: 0.5rem; color: #6b7280;"><em>${escapeHtml(assessment.penjelasan5_2)}</em></p>` : ''}
                <p style="margin-top: 1rem;"><strong>Kesanggupan Melaksanakan 5R:</strong> ${assessment.q5_3 || '-'}</p>
                ${assessment.penjelasan5_3 ? `<p style="margin-top: 0.5rem; color: #6b7280;"><em>${escapeHtml(assessment.penjelasan5_3)}</em></p>` : ''}
                <p style="margin-top: 1rem;"><strong>Pertemuan & Evaluasi (PDCA):</strong> ${assessment.q5_4 || '-'}</p>
                ${assessment.penjelasan5_4 ? `<p style="margin-top: 0.5rem; color: #6b7280;"><em>${escapeHtml(assessment.penjelasan5_4)}</em></p>` : ''}
                <p style="margin-top: 1rem;"><strong>Upaya Perbaikan Berkesinambungan:</strong> ${assessment.q5_5 || '-'}</p>
                ${assessment.penjelasan5_5 ? `<p style="margin-top: 0.5rem; color: #6b7280;"><em>${escapeHtml(assessment.penjelasan5_5)}</em></p>` : ''}
                ${assessment.kendala5_6 ? `<p style="margin-top: 1rem;"><strong>Kendala:</strong></p><p style="margin-top: 0.5rem; color: #6b7280;"><em>${escapeHtml(assessment.kendala5_6)}</em></p>` : ''}
            </div>
        </div>
    `;

    document.getElementById('detailModal').classList.add('active');
}

function editAssessment(id) {
    window.location.href = `form.html?id=${id}`;
}

function deleteAssessment(id) {
    if (!confirm('Apakah Anda yakin ingin menghapus assessment ini?')) return;

    let assessments = getAssessments();
    assessments = assessments.filter(a => a.id !== id);
    saveAssessments(assessments);

    updateStats();
    renderAssessments();

    // Refresh charts if K3
    if (hasRole('k3')) {
        renderCharts();
    }

    showToast('Assessment berhasil dihapus');
}

function closeModal() {
    document.getElementById('detailModal').classList.remove('active');
}

function populateDivisiFilter() {
    const filterDivisi = document.getElementById('filterDivisi');
    if (!filterDivisi) return;

    const assessments = getAssessments();
    const uniqueDivisi = [...new Set(assessments.map(a => a.divisi))].filter(Boolean);

    // Keep the "Semua Divisi" option
    filterDivisi.innerHTML = '<option value="all">Semua Divisi</option>';

    uniqueDivisi.forEach(divisi => {
        const option = document.createElement('option');
        option.value = divisi;
        option.textContent = divisi;
        filterDivisi.appendChild(option);
    });
}

// =====================
// Form Functions
// =====================
let currentEditId = null;

function getFormData() {
    const user = getCurrentUser();
    const formData = {
        id: currentEditId || generateId(),
        nama: document.getElementById('nama').value,
        divisi: document.getElementById('divisi').value,
        jabatan: document.getElementById('jabatan').value,
        periode: document.getElementById('periode').value,
        representative: document.getElementById('representative').checked,
        createdBy: currentEditId ? getAssessmentById(currentEditId)?.createdBy : user.username,
        createdAt: currentEditId ? getAssessmentById(currentEditId)?.createdAt : new Date().toISOString(),
        updatedAt: new Date().toISOString(),

        // Aspek Ringkas
        q1_1: document.querySelector('input[name="q1_1"]:checked')?.value,
        foto1_1: getStoredImage('foto1_1'),
        q1_2: document.querySelector('input[name="q1_2"]:checked')?.value,
        foto1_2: getStoredImage('foto1_2'),
        q1_3: document.querySelector('input[name="q1_3"]:checked')?.value,
        foto1_3: getStoredImage('foto1_3'),
        q1_4: document.querySelector('input[name="q1_4"]:checked')?.value,
        penjelasan1_4: document.getElementById('penjelasan1_4').value,
        q1_5: document.querySelector('input[name="q1_5"]:checked')?.value,
        foto1_5: getStoredImage('foto1_5'),

        // Aspek Rapi
        q2_1: document.querySelector('input[name="q2_1"]:checked')?.value,
        foto2_1: getStoredImage('foto2_1'),
        q2_2: document.querySelector('input[name="q2_2"]:checked')?.value,
        foto2_2: getStoredImage('foto2_2'),
        q2_3: document.querySelector('input[name="q2_3"]:checked')?.value,
        foto2_3: getStoredImage('foto2_3'),
        q2_4: document.querySelector('input[name="q2_4"]:checked')?.value,
        foto2_4: getStoredImage('foto2_4'),
        q2_5: document.querySelector('input[name="q2_5"]:checked')?.value,
        foto2_5: getStoredImage('foto2_5'),

        // Aspek Resik
        q3_1: document.querySelector('input[name="q3_1"]:checked')?.value,
        foto3_1: getStoredImage('foto3_1'),
        q3_2: document.querySelector('input[name="q3_2"]:checked')?.value,
        foto3_2: getStoredImage('foto3_2'),
        q3_3: document.querySelector('input[name="q3_3"]:checked')?.value,
        foto3_3: getStoredImage('foto3_3'),
        q3_4: document.querySelector('input[name="q3_4"]:checked')?.value,
        foto3_4: getStoredImage('foto3_4'),
        q3_5: document.querySelector('input[name="q3_5"]:checked')?.value,
        foto3_5: getStoredImage('foto3_5'),

        // Aspek Rawat
        q4_1: document.querySelector('input[name="q4_1"]:checked')?.value,
        foto4_1: getStoredImage('foto4_1'),
        q4_2: document.querySelector('input[name="q4_2"]:checked')?.value,
        foto4_2: getStoredImage('foto4_2'),

        // Aspek Rajin
        q5_1: document.querySelector('input[name="q5_1"]:checked')?.value,
        penjelasan5_1: document.getElementById('penjelasan5_1').value,
        q5_2: document.querySelector('input[name="q5_2"]:checked')?.value,
        penjelasan5_2: document.getElementById('penjelasan5_2').value,
        q5_3: document.querySelector('input[name="q5_3"]:checked')?.value,
        penjelasan5_3: document.getElementById('penjelasan5_3').value,
        q5_4: document.querySelector('input[name="q5_4"]:checked')?.value,
        penjelasan5_4: document.getElementById('penjelasan5_4').value,
        q5_5: document.querySelector('input[name="q5_5"]:checked')?.value,
        penjelasan5_5: document.getElementById('penjelasan5_5').value,
        kendala5_6: document.getElementById('kendala5_6').value,

        // Pernyataan
        pernyataan: document.getElementById('pernyataan').checked
    };

    // Calculate scores
    formData.scores = calculateScores(formData);

    return formData;
}

function handleSubmit(event) {
    event.preventDefault();

    const data = getFormData();
    saveAssessment(data);

    showToast('Assessment berhasil disimpan!');
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 1500);
}

function saveAssessment(data) {
    let assessments = getAssessments();

    if (currentEditId) {
        const index = assessments.findIndex(a => a.id === currentEditId);
        if (index !== -1) {
            assessments[index] = data;
        }
    } else {
        assessments.push(data);
        currentEditId = data.id;
    }

    saveAssessments(assessments);
}

function loadAssessment(id) {
    const assessment = getAssessmentById(id);
    if (!assessment) return;

    currentEditId = id;

    // Load basic info
    document.getElementById('nama').value = assessment.nama || '';
    document.getElementById('divisi').value = assessment.divisi || '';
    document.getElementById('jabatan').value = assessment.jabatan || '';
    document.getElementById('periode').value = assessment.periode || '';
    document.getElementById('representative').checked = assessment.representative || false;

    // Load radio buttons
    const radioFields = [
        'q1_1', 'q1_2', 'q1_3', 'q1_4', 'q1_5',
        'q2_1', 'q2_2', 'q2_3', 'q2_4', 'q2_5',
        'q3_1', 'q3_2', 'q3_3', 'q3_4', 'q3_5',
        'q4_1', 'q4_2',
        'q5_1', 'q5_2', 'q5_3', 'q5_4', 'q5_5'
    ];

    radioFields.forEach(field => {
        const value = assessment[field];
        if (value) {
            const radio = document.querySelector(`input[name="${field}"][value="${value}"]`);
            if (radio) radio.checked = true;
        }
    });

    // Load textareas
    document.getElementById('penjelasan1_4').value = assessment.penjelasan1_4 || '';
    document.getElementById('penjelasan5_1').value = assessment.penjelasan5_1 || '';
    document.getElementById('penjelasan5_2').value = assessment.penjelasan5_2 || '';
    document.getElementById('penjelasan5_3').value = assessment.penjelasan5_3 || '';
    document.getElementById('penjelasan5_4').value = assessment.penjelasan5_4 || '';
    document.getElementById('penjelasan5_5').value = assessment.penjelasan5_5 || '';
    document.getElementById('kendala5_6').value = assessment.kendala5_6 || '';

    // Load images
    const imageFields = [
        'foto1_1', 'foto1_2', 'foto1_3', 'foto1_5',
        'foto2_1', 'foto2_2', 'foto2_3', 'foto2_4', 'foto2_5',
        'foto3_1', 'foto3_2', 'foto3_3', 'foto3_4', 'foto3_5',
        'foto4_1', 'foto4_2'
    ];

    imageFields.forEach(field => {
        const imageData = assessment[field];
        if (imageData) {
            sessionStorage.setItem(field, imageData);
            showImagePreview(field, imageData);
        }
    });

    // Load pernyataan
    document.getElementById('pernyataan').checked = assessment.pernyataan || false;
}

function getAssessmentById(id) {
    const assessments = getAssessments();
    return assessments.find(a => a.id === id);
}

// =====================
// Image Handling
// =====================
function previewImages(input) {
    const field = input.id;
    const files = Array.from(input.files);
    
    // Validasi jumlah file
    let existingImages = [];
    try {
        const stored = sessionStorage.getItem(field);
        if (stored) {
            existingImages = JSON.parse(stored);
            if (!Array.isArray(existingImages)) {
                existingImages = [stored];
            }
        }
    } catch(e) {
        const stored = sessionStorage.getItem(field);
        if (stored) existingImages = [stored];
    }

    if (existingImages.length + files.length > 3) {
        alert('Maksimal 3 foto yang diperbolehkan');
        input.value = '';
        return;
    }
    
    // Validasi ukuran
    const invalidFiles = files.filter(f => f.size > 1024 * 1024);
    if (invalidFiles.length > 0) {
        alert('Setiap foto maksimal 1MB');
        input.value = '';
        return;
    }

    const processFile = (file) => {
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = function(e) {
                // Compress image to save localStorage space
                const img = new Image();
                img.onload = function() {
                    const canvas = document.createElement('canvas');
                    const MAX_WIDTH = 800;
                    const MAX_HEIGHT = 800;
                    let width = img.width;
                    let height = img.height;

                    if (width > height) {
                        if (width > MAX_WIDTH) {
                            height *= MAX_WIDTH / width;
                            width = MAX_WIDTH;
                        }
                    } else {
                        if (height > MAX_HEIGHT) {
                            width *= MAX_HEIGHT / height;
                            height = MAX_HEIGHT;
                        }
                    }

                    canvas.width = width;
                    canvas.height = height;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);
                    resolve(canvas.toDataURL('image/jpeg', 0.6));
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        });
    };

    Promise.all(files.map(processFile)).then(dataUrls => {
        existingImages = [...existingImages, ...dataUrls];
        sessionStorage.setItem(field, JSON.stringify(existingImages));
        showImagePreview(field, existingImages);
        input.value = ''; // Reset input to allow adding same file again if needed
    });
}

function showImagePreview(field, imagesStrOrArr) {
    const preview = document.getElementById(`preview${field.replace('foto', '')}`);
    if (!preview) return;

    let images = [];
    if (typeof imagesStrOrArr === 'string') {
        try { images = JSON.parse(imagesStrOrArr); } catch(e) { images = [imagesStrOrArr]; }
    } else {
        images = imagesStrOrArr || [];
    }

    if (images.length === 0) {
        preview.innerHTML = '';
        preview.classList.remove('has-image');
        return;
    }

    preview.innerHTML = `<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); gap: 10px; width: 100%;">
        ${images.map((imgData, idx) => `
            <div style="position: relative;">
                <img src="${imgData}" alt="Preview" style="width: 100%; height: 100px; object-fit: cover; border-radius: 8px;">
                <button type="button" class="remove-btn" onclick="removeImageIndex('${field}', ${idx})" style="position: absolute; top: 4px; right: 4px; background: rgba(0,0,0,0.7); color: white; border: none; border-radius: 50%; width: 24px; height: 24px; cursor: pointer; display: flex; align-items: center; justify-content: center;">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M18 6L6 18M6 6l12 12"/>
                    </svg>
                </button>
            </div>
        `).join('')}
    </div>`;
    preview.classList.add('has-image');
}

function removeImageIndex(field, index) {
    let images = [];
    try {
        images = JSON.parse(sessionStorage.getItem(field) || '[]');
        if (!Array.isArray(images)) images = [images];
    } catch(e) {
        const stored = sessionStorage.getItem(field);
        if (stored) images = [stored];
    }
    
    images.splice(index, 1);
    sessionStorage.setItem(field, JSON.stringify(images));
    showImagePreview(field, images);
}

function removeImage(field) {
    sessionStorage.removeItem(field);
    showImagePreview(field, []);
}

function getStoredImage(field) {
    const val = sessionStorage.getItem(field);
    if (!val) return [];
    try {
        const parsed = JSON.parse(val);
        return Array.isArray(parsed) ? parsed : [val];
    } catch(e) {
        return [val];
    }
}

// =====================
// Utility Functions
// =====================
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(isoString) {
    if (!isoString) return '-';
    const date = new Date(isoString);
    return date.toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    });
}

function showToast(message) {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    toastMessage.textContent = message;
    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// =====================
// Event Listeners
// =====================
document.addEventListener('DOMContentLoaded', function() {
    // Initialize TomSelect for dropdowns if available
    if (typeof TomSelect !== 'undefined') {
        const selectEls = ['#divisi', '#jabatan', '#periode'];
        selectEls.forEach(selector => {
            const el = document.querySelector(selector);
            if (el) {
                new TomSelect(el, {
                    create: false,
                    sortField: {
                        field: "text",
                        direction: "asc"
                    }
                });
            }
        });
    }

    // Check auth
    checkAuth();

    // Show/hide role-based elements (run on all pages)
    const user = getCurrentUser();
    if (user) {
        // Show/hide K3 elements
        const k3Elements = document.querySelectorAll('.k3-only');
        k3Elements.forEach(el => {
            if (user.role === 'k3') {
                el.style.display = '';
            } else {
                el.style.display = 'none';
            }
        });

        // Show/hide User elements
        const userElements = document.querySelectorAll('.user-only');
        userElements.forEach(el => {
            if (user.role === 'user') {
                el.style.display = '';
            } else {
                el.style.display = 'none';
            }
        });
    }

    // Login page
    if (document.getElementById('loginForm')) {
        // Set focus on username
        document.getElementById('username').focus();
    }

    // Dashboard page
    if (document.getElementById('assessmentTable')) {
        const user = getCurrentUser();
        updateStats();
        populateDivisiFilter();
        renderAssessments();

        // Render charts for K3
        if (user.role === 'k3') {
            setTimeout(renderCharts, 100);
        }

        // Event listeners
        const searchInput = document.getElementById('searchInput');
        const filterDivisi = document.getElementById('filterDivisi');
        const sortValue = document.getElementById('sortValue');

        if (searchInput) {
            searchInput.addEventListener('input', renderAssessments);
        }
        if (filterDivisi) {
            filterDivisi.addEventListener('change', renderAssessments);
        }
        if (sortValue) {
            sortValue.addEventListener('change', renderAssessments);
        }

        // Update user info in header
        const userInfo = document.getElementById('userInfo');
        if (userInfo) {
            userInfo.innerHTML = `
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #6366f1, #8b5cf6); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 600;">
                        ${user.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                        <div style="font-weight: 600; color: #1f2937;">${user.name}</div>
                        <div style="font-size: 0.75rem; color: #6b7280; text-transform: capitalize;">${user.role}</div>
                    </div>
                    <button onclick="handleLogout()" style="margin-left: 0.5rem; padding: 0.5rem; background: #f3f4f6; border: none; border-radius: 8px; cursor: pointer; color: #6b7280;" title="Logout">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4m7 14l5-5m0 0l-5 5m5-5v-8"/>
                        </svg>
                    </button>
                </div>
            `;
        }
    }

    // Form page
    if (document.getElementById('assessmentForm')) {
        // Check for edit mode
        const urlParams = new URLSearchParams(window.location.search);
        const editId = urlParams.get('id');
        if (editId) {
            loadAssessment(editId);
        }

        // Close modal on outside click
        document.addEventListener('click', function(e) {
            const modal = document.getElementById('detailModal');
            if (e.target === modal || e.target.classList.contains('modal-overlay')) {
                closeModal();
            }
        });
    }

    // Close modal on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
        }
    });
});
